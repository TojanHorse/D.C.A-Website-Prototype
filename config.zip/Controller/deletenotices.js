import prisma from '../DB/db.config.js';
import fs from 'fs';
import path from 'path';
import { redisCache } from '../DB/redis.config.js';
export const deleteNotice = async (req, res) => {
    try {
        const  id  = req.params.id;

        const notice = await prisma.notice.findFirst({
            where: { id: id }
        });

        if (!notice) {
            return res.status(404).json({ message: "Notice not found" });
        }
        await prisma.notice.delete({
            where: { id: id },
        });
        const filePath = path.join(process.cwd(), 'public/Notices', notice.noticeName, notice.noticeFile);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        } else {
            console.warn(`File not found at expected location: ${filePath}`);
        }

        
        redisCache.del("/api/notices/getallNotices", (err) => {
            if (err) {
              console.error("Error clearing cache:", err);
            } else {
              console.log("Cache cleared successfully.");
            }
          });
         
        return res.status(200).json({ message: "Notice and associated file deleted successfully" });
    } catch (error) {
        console.error("Error deleting notice:", error);
        return res.status(500).json({ error: "Failed to delete notice" });
    }
};
