import { generateUrl } from "../Utils/pdfUrl.js";

export const noticeStructure = (notice) => {
    const details = {
        id:notice.id,
        noticeName: notice.noticeName,
        fileName:notice.noticeFile,
        url: generateUrl(notice.folderName, notice.noticeFile)
    };

    return details;
};
