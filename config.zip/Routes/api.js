import {Router} from 'express'
import { verifyJwt } from '../Middleware/authMiddleware.js';
import { addNotice } from '../Controller/addNoticeController.js';
import { Verifyfile } from '../Middleware/fileValidation.js';
import { adminLoginController,adminRegisterController } from '../Controller/adminController.js';
import { reteriveTimeTable } from '../Controller/reteriveTimeTable.js';
import { saveTimeTable } from '../Controller/saveTimeTableController.js';
import { getTimeTableData } from '../Controller/getTimeTableData.js';
import { reteriveNotices } from '../Controller/reteriveNotices.js';
import { downloadPdf } from '../Controller/downloadPdf.js';
import { deleteNotice } from '../Controller/deletenotices.js';
import { reteriveNoticeByDate } from '../Controller/reteriveNotices.js';
import { deleteTimetable } from '../Controller/deleteTimetable.js';
import { addSyllabus } from '../Controller/SyllabusController.js'; 
import { reteriveSyllabus } from '../Controller/reteriveSyllabus.js';
import { deleteSyllabus } from '../Controller/deleteSyllabus.js';
import { redisCache } from '../DB/redis.config.js';
const router = Router();

router.post("/auth/adminRegister",adminRegisterController)
router.post("/auth/adminlogin",redisCache.route(),adminLoginController)
router.post("/timeTable/addTimetable",Verifyfile,saveTimeTable)
router.post("/notices/addNotice",Verifyfile,addNotice)
router.get('/notices/getallNotices',redisCache.route(),reteriveNotices); 
router.get('/download/:folderName/:fileName', downloadPdf);
router.get('/timeTable/getallTimetables',redisCache.route(),reteriveTimeTable); 
router.get('/syllabus/allSyllabus',redisCache.route(),reteriveSyllabus); 
router.post('/timeTable/getTimetableData',redisCache.route(),getTimeTableData); 
router.delete('/notices/deleteNotice/:id',deleteNotice);
router.delete('/deleteTimetable/:id',verifyJwt, deleteTimetable);
router.delete('/syllabus/deleteSyllabus',verifyJwt,deleteSyllabus);
router.get('/notices/by-date',redisCache.route({expire:60*60}), reteriveNoticeByDate);
router.post('/Syllabus/addSyllabus',verifyJwt,addSyllabus);

export default router;